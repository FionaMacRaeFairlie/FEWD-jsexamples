function registerHandlers() {
    document.getElementById("myForm").onsubmit = function(e) {
        // e.preventDefault();  // stop the regular form submission
        return confirm("Are you sure you want to submit?");
    };
}

document.onreadystatechange = function () {
    let state = document.readyState;
    if (state == 'complete') {
        registerHandlers();
    }
}